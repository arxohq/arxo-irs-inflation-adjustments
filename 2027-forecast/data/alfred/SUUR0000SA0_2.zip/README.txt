-------------------------------------------------------------------
Series ID: SUUR0000SA0
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=SUUR0000SA0
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-10-21 5:57 AM CDT
-------------------------------------------------------------------

------------------------------------------------------------------  ---------------  -------------
Title                                                               Real-Time Start  Real-Time End
Chained Consumer Price Index for All Urban Consumers: All Items in  2019-09-12       Current
U.S. City Average
Source
U.S. Bureau of Labor Statistics                                     2011-04-15       Current
Release
Consumer Price Index                                                2011-04-15       Current
Units
Index Dec 1999=100                                                  2011-04-15       Current
Frequency
Monthly                                                             2011-04-15       Current
Seasonal Adjustment
Not Seasonally Adjusted                                             2011-04-15       Current
------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2025-09-11
2026-04-10
2026-08-12
2026-09-11
2026-10-14
----------

